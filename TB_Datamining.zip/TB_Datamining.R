wd <- "D:/wd"
setwd(wd)
getwd()

dataset <- read.csv("train.csv", header = TRUE, sep = ",")
head(dataset)
input=dataset[,2:7]

head(dataset)
View(input)

install.packages("tidyverse")
install.packages("gridExtra")
install.packages("ggplot2")
install.packages("factoextra")
install.packages("cluster")
library(cluster)
library(ggplot2)
library(factoextra)
library(tidyverse)
library(gridExtra)

fviz_nbclust(input,kmeans,method = "silhouette")
k3 <- kmeans(input,centers=3,nstart = 25)
fviz_cluster(k3,geom = "point",data=input)+ggtitle("Data Holiday jika dibagi 3 Cluster")
k3

install.packages("colorspace")
install.packages("maggritr")
library(colorspace)
library(magrittr)

sc <- input %>% scale() %>% dist(method = "euclidean") %>%  hclust(method = "ward.D2")
sc
fviz_dend(sc,k=3,
          cex = 0.5,
          k_colors = c("#2E9FDF","#FC4E07","#00AFBB"),
          color_labels_by_k = TRUE,
          rect = TRUE)
k3$size
